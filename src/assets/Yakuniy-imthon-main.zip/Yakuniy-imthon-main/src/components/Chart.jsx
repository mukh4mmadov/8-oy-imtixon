function Chart() {
    return <div>Chart</div>;
}

export default Chart;
